from __future__ import annotations

import re
from typing import Set

from .debug_log import get_logger
from .hot_words_lexicon import HotWordsLexicon, get_hot_words_lexicon


# ASR common error character variants.  Only include high-confidence mappings;
# ambiguous ones (e.g. 嘎 which is also common filler) are excluded.
_DIRTY_VARIANTS: dict[str, str] = {
    "滴": "的",
    "地": "的",
    "得": "的",
    "尬": "个",
}

# ASR homophone / near-homophone correction for# Only high-confidence mappings (strings that are very commonly
# misrecognised by ASR in the smart-home domain).
_ASR_HOMOPHONE_CORRECTIONS: list[tuple[str, str]] = [
    ("窗连", "窗帘"),
    ("窗廉", "窗帘"),
    ("窗帘连", "窗帘帘"),
    ("社等", "射灯"),
    ("摄等", "射灯"),
    ("森环", "新风"),
    ("生环", "新风"),
    ("声环", "新风"),
    ("森环系统", "新风系统"),
    ("生环系统", "新风系统"),
    ("声环系统", "新风系统"),
    ("登", "灯"),
    ("调为", "调为"),  # no-op, prevents over-correction
    ("射登", "射灯"),
    ("摄登", "射灯"),
]

# ASR whole-word phonetic correction for smart-home device names.
# Keys are common ASR misrecognitions; values are the intended term.
_ASR_HOMOPHONE_CORRECTIONS: dict[str, str] = {
    "窗连": "窗帘",
    "窗廉": "窗帘",
    "窗莲": "窗帘",
    "社等": "射灯",
    "摄等": "射灯",
    "设等": "射灯",
    "射等": "射灯",
    "森环": "新风",
    "森环系统": "新风系统",
    "新风系统": "新风系统",
    "生环": "新风",
    "声控": "声控",
    "登": "灯",
    "灯泡": "灯泡",
    "空调机": "空调",
    "调为": "调为",
}

# Structural particles that carry semantic weight in commands.
_STRUCT_CHARS: frozenset[str] = frozenset("的把到为成给让将用被在从向与比跟")

# Chinese and Arabic digit characters.
_DIGIT_CHARS: frozenset[str] = frozenset("0123456789零一二三四五六七八九十百千万点")

# Unit suffix characters commonly seen in smart-home commands.
_UNIT_CHARS: frozenset[str] = frozenset("度℃%瓦")

# Pattern to collapse consecutive identical structural particles (的的→的, 了了→了).
_DUPLICATE_STRUCT_PATTERN = re.compile(r"(的|了|过|是){2,}")


def _build_hot_char_set(lexicon: HotWordsLexicon) -> Set[str]:
    """Collect every character that appears in any hot-word entry."""
    chars: Set[str] = set()
    for sources in (
        lexicon.action_terms,
        lexicon.set_terms,
        lexicon.temperature_terms,
        lexicon.brightness_terms,
        lexicon.query_terms,
        lexicon.scene_terms,
        lexicon.location_terms,
        lexicon.connectors,
    ):
        if isinstance(sources, (list, tuple)):
            for item in sources:
                text = item[0] if isinstance(item, (list, tuple)) else item
                for ch in text:
                    chars.add(ch)
    # device_terms is Tuple[Tuple[str, str], ...]
    for pair in lexicon.device_terms:
        for ch in pair[0]:
            chars.add(ch)
    return chars


def _build_hot_word_set(lexicon: HotWordsLexicon) -> Set[str]:
    """Collect all multi-character hot words for span matching."""
    words: Set[str] = set()
    for sources in (
        lexicon.action_terms,
        lexicon.device_terms,
    ):
        for item in sources:
            text = item[0] if isinstance(item, (list, tuple)) else item
            if len(text) >= 2:
                words.add(text)
    for terms in (
        lexicon.set_terms,
        lexicon.temperature_terms,
        lexicon.brightness_terms,
        lexicon.query_terms,
        lexicon.scene_terms,
        lexicon.location_terms,
        lexicon.connectors,
    ):
        for term in terms:
            if len(term) >= 2:
                words.add(term)
    return words


class TextDenoiser:
    """Lightweight ASR-text denoiser for smart-home NLU.

    Three-stage pipeline applied before ONNX/LLM inference:

    1. **Filler removal** — strip filler phrases (哈哈, 那个, …) then
       filler characters (啊, 嗯, …) declared in ``hot_words_config.json``.
    2. **Dirty-variant correction + dedup** — fix common ASR substitution
       errors (滴→的, 地→的) and collapse repeated structural particles
       (的的→的).
    3. **Hot-word window extraction** (optional, aggressive) — keep only
       characters that belong to recognised hot-words, structural particles,
       digits, or units.  Falls back to the step-2 result when the
       extraction would discard > 65 % of the original text.

    The denoiser deliberately avoids phonetic / LLM-based correction so
    that it adds zero inference latency and no external dependencies.
    """

    _MIN_KEEP_RATIO = 0.35
    _NOISE_TRIGGER_RATIO = 0.30  # Only apply hot-word window when >30% chars are noise.

    def __init__(self, lexicon: HotWordsLexicon | None = None) -> None:
        self._lexicon = lexicon or get_hot_words_lexicon()
        self._hot_chars = _build_hot_char_set(self._lexicon)
        self._hot_words = _build_hot_word_set(self._lexicon)
        self._sorted_hot_words = sorted(self._hot_words, key=len, reverse=True)
        self._logger = get_logger("text_denoiser")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def denoise(self, text: str) -> str:
        """Denoise ASR text for downstream NLU models."""
        raw = str(text or "").strip()
        if not raw:
            return raw

        # Step 1: Remove filler phrases (longer first) then filler chars.
        cleaned = self._remove_fillers(raw)
        # Step 2: Fix dirty variants + collapse duplicate structural particles.
        cleaned = self._fix_dirty_variants(cleaned)
        cleaned = _DUPLICATE_STRUCT_PATTERN.sub(r"\1", cleaned)
        # Step 2b: Fix ASR homophone errors (窗连→窗帘, 社等→射灯, etc.)
        cleaned = self._fix_asr_homophones(cleaned)
        if not cleaned:
            return raw

        # Step 3: Hot-word window extraction (only when text is genuinely noisy).
        noise_ratio = self._compute_noise_ratio(cleaned)
        if noise_ratio < self._NOISE_TRIGGER_RATIO:
            self._logger.debug(
                "denoise skip_window noise=%.2f raw=%s cleaned=%s",
                noise_ratio, raw, cleaned,
            )
            return cleaned
        extracted = self._extract_hot_window(cleaned)
        if not extracted:
            self._logger.debug("denoise keep_step2 raw=%s cleaned=%s", raw, cleaned)
            return cleaned

        keep_ratio = len(extracted) / max(len(raw), 1)
        if keep_ratio < self._MIN_KEEP_RATIO:
            self._logger.debug(
                "denoise too_aggressive ratio=%.2f raw=%s extracted=%s keep_step2=%s",
                keep_ratio, raw, extracted, cleaned,
            )
            return cleaned

        self._logger.debug(
            "denoise ok ratio=%.2f raw=%s -> %s", keep_ratio, raw, extracted,
        )
        return extracted

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _compute_noise_ratio(self, text: str) -> float:
        """Fraction of characters that are neither hot-chars, structural, digits,
        units, nor common punctuation."""
        if not text:
            return 0.0
        noise = 0
        for ch in text:
            if ch in self._hot_chars:
                continue
            if ch in _STRUCT_CHARS or ch in _DIGIT_CHARS or ch in _UNIT_CHARS:
                continue
            if ch in "，,；;。！？!？、和与给把从到":
                continue
            noise += 1
        return noise / len(text)

    def _remove_fillers(self, text: str) -> str:
        """Strip filler phrases and filler characters from the lexicon."""
        result = text
        for phrase in self._lexicon.filler_phrases:
            result = result.replace(phrase, "")
        for ch in self._lexicon.filler_chars:
            result = result.replace(ch, "")
        return result

    @staticmethod
    def _fix_dirty_variants(text: str) -> str:
        """Correct common ASR recognition errors."""
        return "".join(_DIRTY_VARIANTS.get(ch, ch) for ch in text)

    @staticmethod
    def _fix_asr_homophones(text: str) -> str:
        """Correct common ASR homophone / near-homophone errors for device names."""
        result = text
        for wrong, correct in _ASR_HOMOPHONE_CORRECTIONS:
            if wrong in result:
                result = result.replace(wrong, correct)
        return result

    def _extract_hot_window(self, text: str) -> str:
        """Keep only hot-word spans, structural chars, digits, and units.

        Uses greedy longest-first matching of multi-character hot words,
        then preserves single characters that are hot-chars, structural,
        digits, or units.  Everything else is discarded as noise.
        """
        n = len(text)
        covered = [False] * n
        emit: list[str | None] = [None] * n

        # Pass 1: greedy hot-word matching (longest first).
        for word in self._sorted_hot_words:
            wlen = len(word)
            start = 0
            while start <= n - wlen:
                pos = text.find(word, start)
                if pos == -1:
                    break
                if not covered[pos]:
                    for i in range(pos, pos + wlen):
                        covered[i] = True
                    emit[pos] = word
                    for i in range(pos + 1, pos + wlen):
                        emit[i] = ""
                start = pos + wlen

        # Pass 2: single-char check for uncovered positions.
        for i in range(n):
            if covered[i]:
                continue
            ch = text[i]
            if ch in _STRUCT_CHARS or ch in _DIGIT_CHARS or ch in _UNIT_CHARS:
                covered[i] = True
                emit[i] = ch
            elif ch in self._hot_chars:
                covered[i] = True
                emit[i] = ch

        return "".join(tok for tok in emit if tok)
